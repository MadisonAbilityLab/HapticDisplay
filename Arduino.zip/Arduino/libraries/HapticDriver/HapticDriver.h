/*
*/

#ifndef HaptiDriver_h
#define HaptiDriver_h

#include "Peg.h"

class HapticDriver{
    private:


    public:



};


#endif